import { fork, spawn } from "node:child_process";
import { realpath } from "node:fs/promises";
import { homedir } from "node:os";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import {
  checkForUpdate,
  ensureSeed,
  launchCandidates,
  readChannel,
  rejectVersion,
} from "./updater.mjs";

const launcher = fileURLToPath(import.meta.url);
const fourHours = 4 * 60 * 60 * 1000;

async function verifyPage(origin, html) {
  // Vite emits quoted src/href attributes. Verify entry assets against the running
  // server so its SPA fallback cannot hide a missing bundle behind a 200 response.
  const assets = [];
  for (const [tag] of html.matchAll(/<(?:script|link)\b[^>]*>/gi)) {
    const script = /^<script\b/i.test(tag);
    if (!script && !/\srel=["']stylesheet["']/i.test(tag)) continue;
    const source = (
      script ? /\ssrc=["']([^"']+)["']/i : /\shref=["']([^"']+)["']/i
    ).exec(tag)?.[1];
    if (!source) continue;
    const url = new URL(source, origin);
    if (url.origin !== origin || url.username || url.password)
      throw new Error("Recurso de arranque ajeno al origen local.");
    assets.push({ url, script });
  }
  if (!assets.some((asset) => asset.script) || assets.length > 64)
    throw new Error("Página de inicio sin recursos de aplicación válidos.");
  await Promise.all(
    assets.map(async ({ url, script }) => {
      const asset = await fetch(url, {
        redirect: "error",
        signal: AbortSignal.timeout(5000),
      });
      const mime = asset.headers
        .get("content-type")
        ?.split(";")[0]
        .trim()
        .toLowerCase();
      const correctType = script
        ? ["application/javascript", "text/javascript"].includes(mime)
        : mime === "text/css";
      if (!asset.ok || !correctType || !(await asset.arrayBuffer()).byteLength)
        throw new Error("Falta un recurso de arranque de la interfaz.");
    }),
  );
}

async function serve(directory, port) {
  // The supervisor owns this server. A closed terminal must also release the local port.
  process.once("disconnect", () => process.exit(0));
  const version = path.basename(directory);
  let pendingVersion = null;
  process.on("message", (message) => {
    if (message?.type === "update") pendingVersion = message.version;
  });
  try {
    const entry = await import(
      pathToFileURL(path.join(directory, "server/index.mjs"))
    );
    await entry.validateInstallation?.();
    const server = await entry.createServer({
      port,
      getUpdateStatus: () => ({ version, pendingVersion }),
    });
    const address = server.address();
    if (address?.address !== "127.0.0.1")
      throw new Error("Se esperaba un servidor en loopback.");
    const origin = new URL(`http://127.0.0.1:${address.port}`).origin;
    const [page, session] = await Promise.all([
      fetch(origin, { redirect: "error", signal: AbortSignal.timeout(5000) }),
      fetch(origin + "/api/session", {
        redirect: "error",
        signal: AbortSignal.timeout(5000),
      }),
    ]);
    if (!page.ok || !session.ok || !(await session.json()).token)
      throw new Error("El servidor no pudo servir la aplicación y su sesión.");
    await verifyPage(origin, await page.text());
    process.send({ type: "ready", origin });
  } catch (error) {
    process.send(
      { type: "failure", message: error.message, code: error.code },
      () => process.exit(1),
    );
  }
}

function openBrowser(origin) {
  const command =
    { darwin: "open", win32: "rundll32" }[process.platform] ?? "xdg-open";
  const args =
    process.platform === "win32"
      ? ["url.dll,FileProtocolHandler", origin]
      : [origin];
  const browser = spawn(command, args, { stdio: "ignore", detached: true });
  browser.on("error", () => console.log(`Abre ${origin} en tu navegador.`));
  browser.unref();
}

async function startVersion(directory, port) {
  const child = fork(launcher, ["--serve", directory, String(port)], {
    execArgv: [],
    stdio: ["ignore", "inherit", "inherit", "ipc"],
  });
  const done = new Promise((resolve) => {
    child.once("exit", (code, signal) => resolve({ code, signal }));
    child.once("error", (error) => resolve({ code: 1, error }));
  });
  let timer;
  try {
    const ready = new Promise((resolve, reject) => {
      timer = setTimeout(
        () => reject(new Error("Tiempo de arranque agotado.")),
        30_000,
      );
      child.once("message", (message) => {
        if (message?.type === "ready") resolve(message.origin);
        else
          reject(
            Object.assign(new Error(message?.message || "Error de arranque."), {
              code: message?.code,
            }),
          );
      });
    });
    const origin = await Promise.race([
      ready,
      done.then(({ error }) => {
        throw error ?? new Error("El servidor terminó durante el arranque.");
      }),
    ]);
    return { child, origin, done };
  } catch (error) {
    child.kill("SIGKILL");
    await done;
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export async function launch({
  runtimeDir = path.dirname(launcher),
  storeBase = process.env.INTEGRATION_DESK_RUNTIME_DIR ||
    path.join(homedir(), ".integration-desk-runtime"),
  port = Number(process.env.INTEGRATION_DESK_PORT || 4310),
  open = false,
  fetchImpl = fetch,
  log = console.log,
} = {}) {
  if (!Number.isInteger(port) || port < 0 || port > 65535)
    throw new Error("Puerto inválido.");
  const channel = await readChannel(runtimeDir, storeBase);
  try {
    await ensureSeed(runtimeDir, channel);
  } catch (error) {
    if (!(await launchCandidates(channel).catch(() => [])).length) throw error;
    log(
      `Paquete inicial no disponible. Se usará una versión instalada. ${error.message}`,
    );
  }
  const failed = [];
  for (const version of await launchCandidates(channel)) {
    let running;
    try {
      running = await startVersion(path.join(channel.versions, version), port);
    } catch (error) {
      // A second launch or local OS restriction is independent of the installed release.
      if (
        [
          "EADDRINUSE",
          "EACCES",
          "EPERM",
          "EMFILE",
          "ENFILE",
          "ENOMEM",
        ].includes(error.code)
      )
        throw error;
      failed.push(version);
      log(`Integration Desk ${version} no arrancó. ${error.message}`);
      continue;
    }

    // Only quarantine a failed release after an older version has actually passed its health check.
    for (const broken of failed) {
      await rejectVersion(channel, broken).catch(() =>
        log(`No se pudo marcar la versión ${broken} como fallida.`),
      );
    }
    log(`Integration Desk ${version}: ${running.origin}`);
    if (open) openBrowser(running.origin);
    const stop = new AbortController();
    let checking;
    const check = () => {
      checking ??= checkForUpdate(channel, { fetchImpl, signal: stop.signal })
        .then((next) => {
          if (next && running.child.connected) {
            running.child.send({ type: "update", version: next }, () => {});
            log(
              `Actualización ${next} preparada. Se aplicará la próxima vez que abras Integration Desk.`,
            );
          }
          return next;
        })
        .catch((error) => {
          if (!stop.signal.aborted)
            log(`Actualización pendiente de comprobar. ${error.message}`);
          return null;
        })
        .finally(() => {
          checking = undefined;
        });
      return checking;
    };
    const interval = setInterval(check, fourHours).unref();
    void running.done.then(() => {
      clearInterval(interval);
      stop.abort();
    });
    return { ...running, version, updateCheck: check() };
  }
  throw new Error("Ninguna versión instalada pudo iniciarse.");
}

const isMain =
  import.meta.main ??
  (process.argv[1] &&
    (await realpath(process.argv[1]).catch(() => null)) === launcher);
if (isMain) {
  try {
    if (process.argv[2] === "--serve" && process.send) {
      await serve(process.argv[3], Number(process.argv[4]));
    } else {
      const running = await launch({ open: process.argv.includes("--open") });
      const { code, signal } = await running.done;
      process.exitCode = code ?? (signal === "SIGINT" ? 0 : 1);
    }
  } catch (error) {
    console.error(
      error.code === "EADDRINUSE"
        ? "El puerto de Integration Desk está ocupado. Cierra la instancia anterior para volver a abrirla."
        : error.message,
    );
    process.exitCode = 1;
  }
}
