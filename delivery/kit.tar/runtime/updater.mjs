import { createHash, createPublicKey, verify } from "node:crypto";
import {
  access,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rename,
  rm,
  stat,
  writeFile,
} from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import { gunzip } from "node:zlib";

const decompress = promisify(gunzip);
const versionPattern = /^(0|[1-9]\d{0,8})\.(0|[1-9]\d{0,8})\.(0|[1-9]\d{0,8})$/;
const digestPattern = /^[a-f0-9]{64}$/;
const maxArchive = 32 * 1024 * 1024;
const maxUnpacked = 96 * 1024 * 1024;
const marker = ".integration-desk-rejected";
const payloadName = "integration-desk-app.json.gz";
const manifestName = "integration-desk-manifest.json";
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");

function requireValue(condition, message) {
  if (!condition) throw new Error(message);
}

function isVersion(value) {
  return typeof value === "string" && versionPattern.test(value);
}

function compare(a, b) {
  const left = a.split(".").map(Number);
  const right = b.split(".").map(Number);
  return left[0] - right[0] || left[1] - right[1] || left[2] - right[2];
}

export async function readChannel(runtimeDir, storeBase) {
  const config = JSON.parse(
    await readFile(path.join(runtimeDir, "channel.json"), "utf8"),
  );
  requireValue(
    typeof config.repository === "string" &&
      /^[A-Za-z0-9-]+\/[A-Za-z0-9_-][A-Za-z0-9._-]*$/.test(config.repository) &&
      isVersion(config.version) &&
      digestPattern.test(config.sha256),
    "Configuración del instalador inválida.",
  );
  const key = createPublicKey(config.publicKey);
  requireValue(
    key.asymmetricKeyType === "ed25519",
    "Clave de publicación inválida.",
  );
  const fingerprint = createHash("sha256")
    .update(config.repository.toLowerCase())
    .update(key.export({ type: "spki", format: "der" }))
    .digest("hex")
    .slice(0, 32);
  return {
    ...config,
    key,
    versions: path.join(storeBase, fingerprint, "versions"),
  };
}

function isPortablePath(name) {
  if (name.length > 220) return false;
  return name
    .split("/")
    .every(
      (part) =>
        /^[A-Za-z0-9_@+-][A-Za-z0-9_.@+ -]*$/.test(part) &&
        !/[. ]$/.test(part) &&
        !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part),
    );
}

async function exists(filename) {
  try {
    await access(filename);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

// A directory only becomes selectable once its complete tree has been verified and renamed.
async function install(bytes, { version, sha256: digest }, versions, signal) {
  signal?.throwIfAborted();
  requireValue(
    bytes.length <= maxArchive && sha256(bytes) === digest,
    "Suma SHA-256 incorrecta.",
  );
  const unpacked = await decompress(bytes, { maxOutputLength: maxUnpacked });
  signal?.throwIfAborted();
  const app = JSON.parse(unpacked.toString());
  requireValue(
    app.schema === 1 &&
      app.version === version &&
      app.files &&
      typeof app.files === "object" &&
      !Array.isArray(app.files) &&
      Object.hasOwn(app.files, "server/index.mjs") &&
      app.files["server/index.mjs"] &&
      Object.hasOwn(app.files, "dist/index.html") &&
      app.files["dist/index.html"],
    "Contenido incompleto o versión incorrecta.",
  );
  const entries = Object.entries(app.files);
  requireValue(
    entries.length <= 6000,
    "Demasiados archivos en la actualización.",
  );
  const seen = new Set();
  const staging = await mkdtemp(path.join(versions, ".install-"));
  try {
    for (const [name, data] of entries) {
      signal?.throwIfAborted();
      requireValue(
        isPortablePath(name) && !seen.has(name.toLowerCase()),
        "Ruta de archivo inválida o repetida.",
      );
      seen.add(name.toLowerCase());
      requireValue(typeof data === "string", "Contenido de archivo inválido.");
      const content = Buffer.from(data, "base64");
      requireValue(
        content.toString("base64") === data,
        "Archivo en base64 inválido.",
      );
      const filename = path.join(staging, name);
      await mkdir(path.dirname(filename), { recursive: true, mode: 0o700 });
      await writeFile(filename, content, { flag: "wx", mode: 0o600, signal });
    }
    signal?.throwIfAborted();
    try {
      await rename(staging, path.join(versions, version));
    } catch (error) {
      // Concurrent launchers may have installed the same immutable release first.
      if (!(await exists(path.join(versions, version, "server", "index.mjs"))))
        throw error;
    }
  } finally {
    await rm(staging, { recursive: true, force: true });
  }
}

export async function ensureSeed(runtimeDir, channel) {
  await mkdir(channel.versions, { recursive: true, mode: 0o700 });
  if (await exists(path.join(channel.versions, channel.version))) return;
  const filename = path.join(runtimeDir, "app.json.gz");
  requireValue(
    (await stat(filename)).size <= maxArchive,
    "Paquete inicial demasiado grande.",
  );
  await install(await readFile(filename), channel, channel.versions);
}

async function installedVersions(channel) {
  const entries = await readdir(channel.versions, { withFileTypes: true });
  return entries
    .filter((entry) => entry.isDirectory() && isVersion(entry.name))
    .map((entry) => entry.name)
    .sort((a, b) => compare(b, a));
}

export async function launchCandidates(channel) {
  const available = [];
  for (const version of await installedVersions(channel)) {
    if (!(await exists(path.join(channel.versions, version, marker))))
      available.push(version);
  }
  return available;
}

export async function rejectVersion(channel, version) {
  requireValue(isVersion(version), "Versión inválida.");
  await writeFile(path.join(channel.versions, version, marker), "", {
    mode: 0o600,
  });
}

async function download(url, limit, { fetchImpl, signal, asset = false }) {
  const deadline = AbortSignal.timeout(60_000);
  const requestSignal = signal ? AbortSignal.any([signal, deadline]) : deadline;
  for (let redirects = 0; redirects <= 3; redirects++) {
    requestSignal.throwIfAborted();
    const response = await fetchImpl(url, {
      signal: requestSignal,
      redirect: "manual",
      credentials: "omit",
      headers: {
        Accept: asset
          ? "application/octet-stream"
          : "application/vnd.github+json",
        "User-Agent": "Integration-Desk-Updater",
      },
    });
    if (requestSignal.aborted) {
      response.body?.cancel().catch(() => {});
      requestSignal.throwIfAborted();
    }
    if (asset && [301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      await response.body?.cancel();
      requireValue(location, "Redirección sin destino.");
      const target = new URL(location, url);
      requireValue(
        [
          "https://release-assets.githubusercontent.com",
          "https://objects.githubusercontent.com",
          "https://github-releases.githubusercontent.com",
        ].includes(target.origin) &&
          !target.username &&
          !target.password,
        "Redirección de descarga no permitida.",
      );
      url = target.href;
      continue;
    }
    if (
      !response.ok ||
      !response.body ||
      Number(response.headers.get("content-length")) > limit
    ) {
      await response.body?.cancel();
      throw new Error(
        `Descarga no disponible (HTTP ${response.status}) o tamaño excesivo.`,
      );
    }
    const reader = response.body.getReader();
    const cancel = () => {
      void reader.cancel().catch(() => {});
    };
    requestSignal.addEventListener("abort", cancel, { once: true });
    try {
      const chunks = [];
      let size = 0;
      while (true) {
        const { done, value } = await reader.read();
        requestSignal.throwIfAborted();
        if (done) return Buffer.concat(chunks, size);
        size += value.length;
        requireValue(size <= limit, "Descarga demasiado grande.");
        chunks.push(value);
      }
    } catch (error) {
      cancel();
      throw error;
    } finally {
      requestSignal.removeEventListener("abort", cancel);
      reader.releaseLock();
    }
  }
  throw new Error("Demasiadas redirecciones de descarga.");
}

export async function checkForUpdate(
  channel,
  { fetchImpl = fetch, signal } = {},
) {
  const options = { fetchImpl, signal };
  const latest = JSON.parse(
    (
      await download(
        `https://api.github.com/repos/${channel.repository}/releases/latest`,
        512 * 1024,
        options,
      )
    ).toString(),
  );
  if (
    latest.draft !== false ||
    latest.prerelease !== false ||
    typeof latest.tag_name !== "string"
  )
    return null;
  const version = latest.tag_name.replace(/^v/, "");
  if (!isVersion(version)) return null;
  if (await exists(path.join(channel.versions, version))) return null;
  // A rejected higher release must not block a later patch of the working branch.
  const [newest] = await launchCandidates(channel);
  if (compare(version, newest ?? channel.version) <= 0) return null;
  const assetRoot = `https://github.com/${channel.repository}/releases/download/${latest.tag_name}/`;
  const assetOptions = { ...options, asset: true };
  const manifest = JSON.parse(
    (await download(assetRoot + manifestName, 4096, assetOptions)).toString(),
  );
  requireValue(
    manifest.schema === 1 &&
      manifest.version === version &&
      typeof manifest.sha256 === "string" &&
      digestPattern.test(manifest.sha256) &&
      Number.isSafeInteger(manifest.size) &&
      manifest.size > 0 &&
      manifest.size <= maxArchive &&
      typeof manifest.signature === "string" &&
      /^[a-zA-Z0-9+/]{86}==$/.test(manifest.signature),
    "Manifiesto de actualización inválido.",
  );
  const signed = Buffer.from(
    JSON.stringify([1, version, manifest.sha256, manifest.size]),
  );
  requireValue(
    verify(
      null,
      signed,
      channel.key,
      Buffer.from(manifest.signature, "base64"),
    ),
    "Firma de actualización inválida.",
  );
  const bytes = await download(
    assetRoot + payloadName,
    manifest.size,
    assetOptions,
  );
  requireValue(bytes.length === manifest.size, "Descarga incompleta.");
  await install(bytes, manifest, channel.versions, signal);
  return version;
}
