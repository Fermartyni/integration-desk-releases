## Novedades de la versión 1.7.0

- En OData puedes seleccionar un campo o una relación del inspector para resaltarlos en el grafo. Las aristas también abren su detalle en el inspector.
- Explora relaciones entrantes y salientes, salta a la otra entidad y despliega campos complejos por niveles. El grafo dibuja flechas en ambos sentidos cuando el EDMX declara ambas navegaciones como un par.
- El botón de menú del encabezado pliega la barra global. El aviso de actualización sigue visible desde el espacio de trabajo cuando la barra está plegada.

## Abrir Integration Desk

Descarga el ZIP que corresponda a tu equipo y extrae la carpeta completa. Cada paquete incluye Node.js y la aplicación. Conserva la carpeta del lanzador.

| Equipo                                        | ZIP             | Archivo que abre la aplicación   |
| --------------------------------------------- | --------------- | -------------------------------- |
| Windows con procesador Intel o AMD de 64 bits | `windows-x64`   | `Abrir Integration Desk.cmd`     |
| Windows con procesador ARM de 64 bits         | `windows-arm64` | `Abrir Integration Desk.cmd`     |
| Mac con chip de Apple (serie M)               | `macos-arm64`   | `Abrir Integration Desk.command` |
| Mac con procesador Intel                      | `macos-x64`     | `Abrir Integration Desk.command` |
| Linux con procesador Intel o AMD de 64 bits   | `linux-x64`     | `./abrir-integration-desk.sh`    |
| Linux con procesador ARM de 64 bits           | `linux-arm64`   | `./abrir-integration-desk.sh`    |

El runtime incluido requiere Windows 10 o posterior, macOS 13.5 o posterior, o Linux con kernel 4.18 o posterior, glibc 2.28 y libstdc++ con GLIBCXX_3.4.25 o posteriores. Para las conexiones necesitas un navegador con Web Crypto e IndexedDB. [Plataformas compatibles de Node.js 24.22.3](https://github.com/nodejs/node/blob/v24.22.3/BUILDING.md#platform-list)

El lanzador abre Integration Desk en tu navegador. Mantenlo abierto mientras trabajas. Para salir, pulsa Ctrl+C en la terminal del lanzador.

Si ya tienes conexiones, cierra el lanzador anterior y utiliza el mismo navegador, perfil y dirección que antes (por defecto, `http://127.0.0.1:4310`). Tu bóveda cifrada, idioma y tema pertenecen a ese perfil.

Las nuevas versiones de la aplicación se descargan en segundo plano. Cuando el aviso indique que una versión está preparada, cierra y vuelve a abrir el lanzador para usarla.
