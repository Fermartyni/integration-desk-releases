import { createHash, randomUUID } from "node:crypto";
import { execFileSync } from "node:child_process";
import { homedir } from "node:os";
import { mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";

export const nodeVersion = "24.22.3";

// nodejs.org/dist/v24.22.3/SHASUMS256.txt, verified against the detached
// release signature by 5BE8A3F6C8A5C01D106C0AD820B1A390B168D356.
const archives = {
  "macos-arm64": [
    "darwin-arm64",
    "ff6e17d4874b76d272212b908cc020d6e815fba5a6c7eaaa06add725840307fd",
  ],
  "macos-x64": [
    "darwin-x64",
    "977614af0504c81045e7fd85596dbca0e5f951b96681516dadafedcca8c447f7",
  ],
  "windows-x64": [
    "win-x64",
    "e612af99f626ab415ea225af6bce5c971feb448cb5cae250bb1c3fa50c5f7d9f",
  ],
  "windows-arm64": [
    "win-arm64",
    "b3cc74a295b39d4f273271e96f58c06dd2b35757ca12abec64c7d0598b434f14",
  ],
  "linux-x64": [
    "linux-x64",
    "061ec3e3062115705b56b51fa9cc330ab50d34b6969387d4e4b1a50c6809acc2",
  ],
  "linux-arm64": [
    "linux-arm64",
    "261af2af250dfd7e9f25cf151d1b2713a0adf8f10a9ad116c4947f68627affe8",
  ],
};
export const targets = Object.keys(archives);

export async function getRuntime(target) {
  const [platform, expected] = archives[target];
  const windows = target.startsWith("windows-");
  const directory = `node-v${nodeVersion}-${platform}`;
  const filename = directory + (windows ? ".zip" : ".tar.gz");
  const cache = path.join(
    process.env.XDG_CACHE_HOME || path.join(homedir(), ".cache"),
    "integration-desk",
    "build-node",
  );
  await mkdir(cache, { recursive: true });
  const archive = path.join(cache, filename);
  const hash = (data) => createHash("sha256").update(data).digest("hex");
  let data = await readFile(archive).catch((error) => {
    if (error.code !== "ENOENT") throw error;
  });
  if (!data || hash(data) !== expected) {
    const url = `https://nodejs.org/dist/v${nodeVersion}/${filename}`;
    const response = await fetch(url, {
      redirect: "error",
      signal: AbortSignal.timeout(180000),
    });
    if (!response.ok)
      throw new Error(`Descarga de Node fallida (${response.status}).`);
    data = Buffer.from(await response.arrayBuffer());
    if (hash(data) !== expected)
      throw new Error(`SHA-256 de Node incorrecto: ${filename}`);
    const temp = archive + "." + randomUUID();
    try {
      await writeFile(temp, data, { flag: "wx" });
      await rename(temp, archive);
    } finally {
      await rm(temp, { force: true });
    }
  }
  if (windows) {
    const zip = await JSZip.loadAsync(data);
    return {
      binary: await zip.file(`${directory}/node.exe`).async("nodebuffer"),
      license: await zip.file(`${directory}/LICENSE`).async("nodebuffer"),
    };
  }
  const extract = (entry) =>
    execFileSync("tar", ["-xOzf", archive, `${directory}/${entry}`], {
      maxBuffer: 180 * 1024 * 1024,
    });
  return { binary: extract("bin/node"), license: extract("LICENSE") };
}
