import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { createHash, verify } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import JSZip from "jszip";
import { targets } from "./node-runtime.mjs";

const { values } = parseArgs({
  options: {
    check: { type: "boolean" },
    help: { type: "boolean", short: "h" },
  },
});
if (values.help) {
  console.log(
    "node scripts/publish-release.mjs [--check]\nCon --check, valida los paquetes en local. Sin opciones, publica la versión.",
  );
  process.exit(0);
}

const root = fileURLToPath(new URL("../", import.meta.url));
const releaseDir = path.join(root, "releases");
const { repository, publicKey } = JSON.parse(
  await readFile(new URL("release-channel.json", import.meta.url)),
);
const { version } = JSON.parse(await readFile(path.join(root, "package.json")));
const tag = "v" + version;
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const payloadName = "integration-desk-app.json.gz";
const manifestName = "integration-desk-manifest.json";
const manifestBytes = await readFile(path.join(releaseDir, manifestName));
const manifest = JSON.parse(manifestBytes);
const payload = await readFile(path.join(releaseDir, payloadName));
assert.equal(
  manifest.version,
  version,
  "La versión compilada difiere de package.json",
);
assert.equal(manifest.schema, 1);
assert.equal(manifest.size, payload.length);
assert.equal(manifest.sha256, sha256(payload));
assert(
  verify(
    null,
    Buffer.from(JSON.stringify([1, version, manifest.sha256, manifest.size])),
    publicKey,
    Buffer.from(manifest.signature, "base64"),
  ),
  "Firma incorrecta",
);
const digests = new Map([
  [manifestName, sha256(manifestBytes)],
  [payloadName, manifest.sha256],
]);
for (const target of targets) {
  const name = `Integration-Desk-${version}-${target}.zip`;
  const data = await readFile(path.join(releaseDir, name));
  const zip = await JSZip.loadAsync(data);
  const runtime = zip.folder("Integration-Desk/runtime");
  const channel = JSON.parse(
    await runtime.file("channel.json").async("string"),
  );
  assert.deepEqual(channel, {
    repository,
    publicKey,
    version,
    sha256: manifest.sha256,
  });
  assert.equal(
    sha256(await runtime.file("app.json.gz").async("nodebuffer")),
    manifest.sha256,
  );
  for (const file of ["launcher.mjs", "updater.mjs"]) {
    assert.deepEqual(
      await runtime.file(file).async("nodebuffer"),
      await readFile(path.join(root, "runtime", file)),
    );
  }
  digests.set(name, sha256(data));
}
if (values.check) {
  console.log(`Verificados ${digests.size} archivos de ${tag}.`);
  process.exit(0);
}

const gh = (args) =>
  execFileSync("gh", args, {
    encoding: "utf8",
    stdio: ["ignore", "pipe", "inherit"],
  }).trim();
const ghRelease = (...args) => gh(["release", ...args, "--repo", repository]);
const info = JSON.parse(
  gh(["repo", "view", repository, "--json", "visibility,nameWithOwner"]),
);
assert.equal(info.nameWithOwner.toLowerCase(), repository.toLowerCase());
assert.equal(
  info.visibility,
  "PUBLIC",
  "Los clientes necesitan un canal público",
);
const existing = JSON.parse(
  ghRelease("list", "--limit", "100", "--json", "tagName,isLatest,isDraft"),
);
const current = existing.find((release) => release.isLatest);
const draft = existing.find((release) => release.tagName === tag);
const remoteAssets = () =>
  JSON.parse(ghRelease("view", tag, "--json", "assets")).assets;
function verifyRemote() {
  const assets = remoteAssets();
  assert.equal(assets.length, digests.size, "Faltan archivos en GitHub");
  for (const asset of assets)
    assert.equal(asset.digest, "sha256:" + digests.get(asset.name), asset.name);
}
if (draft && !draft.isDraft) {
  verifyRemote();
  console.log(`La versión ${tag} ya está publicada con estos mismos archivos.`);
  process.exit(0);
}
if (current) {
  const parse = (value) => {
    assert(
      /^v?\d+\.\d+\.\d+$/.test(value),
      "El canal usa otra convención de versiones.",
    );
    return value.replace(/^v/, "").split(".").map(Number);
  };
  const previous = parse(current.tagName);
  const firstChange = parse(tag)
    .map((component, i) => component - previous[i])
    .find((delta) => delta !== 0);
  assert(
    firstChange > 0,
    "La versión debe ser posterior a la última publicada.",
  );
}
if (!draft)
  ghRelease(
    "create",
    tag,
    "--draft",
    "--title",
    `Integration Desk ${version}`,
    "--notes-file",
    path.join(root, "docs", "RELEASE-NOTES.md"),
  );
const prior = remoteAssets();
assert(
  prior.every((asset) => digests.has(asset.name)),
  "El borrador contiene archivos ajenos al paquete.",
);
const missing = [...digests].filter(
  ([name, hash]) =>
    !prior.some((a) => a.name === name && a.digest === "sha256:" + hash),
);
if (missing.length)
  ghRelease(
    "upload",
    tag,
    "--clobber",
    ...missing.map(([name]) => path.join(releaseDir, name)),
  );
verifyRemote();
ghRelease("edit", tag, "--draft=false", "--latest");
console.log(`https://github.com/${repository}/releases/tag/${tag}`);
