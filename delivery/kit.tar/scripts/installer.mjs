import { createWriteStream } from "node:fs";
import path from "node:path";
import { pipeline } from "node:stream/promises";
import JSZip from "jszip";
import { getRuntime } from "./node-runtime.mjs";

function launcher(target) {
  if (target.startsWith("windows-"))
    return {
      name: "Abrir Integration Desk.cmd",
      script:
        [
          "@echo off",
          "setlocal",
          'set "NODE_USE_SYSTEM_CA=1"',
          '"%~dp0runtime\\node.exe" "%~dp0runtime\\launcher.mjs" --open',
          "if errorlevel 1 (",
          "  pause",
          "  exit /b 1",
          ")",
          "",
        ].join("\r\n"),
    };
  return {
    name: target.startsWith("macos-")
      ? "Abrir Integration Desk.command"
      : "abrir-integration-desk.sh",
    script:
      '#!/bin/sh\nset -eu\ncd "$(dirname "$0")"\nexec ./runtime/node ./runtime/launcher.mjs --open\n',
  };
}

export async function installer(staging, target, channel, payload, bootstrap) {
  const runtime = await getRuntime(target);
  const zip = new JSZip();
  const add = (name, data, mode = 0o644) =>
    zip.file("Integration-Desk/" + name, data, {
      date: new Date("2000-01-01T00:00:00.000Z"),
      createFolders: false,
      unixPermissions: 0o100000 | mode,
    });
  const open = launcher(target);
  add(open.name, open.script, 0o755);
  add(
    "runtime/" + (target.startsWith("windows-") ? "node.exe" : "node"),
    runtime.binary,
    0o755,
  );
  add("runtime/LICENSE-Node.txt", runtime.license);
  for (const [name, data] of bootstrap) add(name, data);
  add("runtime/channel.json", JSON.stringify(channel, null, 2) + "\n");
  add("runtime/app.json.gz", payload);
  const file = `Integration-Desk-${channel.version}-${target}.zip`;
  await pipeline(
    zip.generateNodeStream({
      type: "nodebuffer",
      streamFiles: true,
      platform: "UNIX",
      compression: "DEFLATE",
      compressionOptions: { level: 5 },
    }),
    createWriteStream(path.join(staging, file), { flags: "wx" }),
  );
  console.log(file);
}
